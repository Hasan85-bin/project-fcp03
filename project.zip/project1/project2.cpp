#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>
using namespace std;
void drop(string code);
void report(string code);
void listingCodes(fstream &data, vector<string> &vec){
    string code, name, field;
    while (data >> code >> name >> field) {
        vec.push_back(code);
    }
}
void listingScores(fstream &file, vector<float> &gpas, vector<string> &codes){
    float ss, sv;
    string code, lesson;
    int vahed;
    float score;
    file.open("scores.txt", ios::in);
    for(string scode: codes){
        file.clear();
        file.seekg(0);
        ss=0;
        sv=0;
        while(file>>code>>lesson>>vahed>>score){
            if(scode==code){
                sv+=vahed;
                ss+=score*vahed;
            }
        }
        if(sv!=0)
            gpas.push_back(ss/sv);
        else
            gpas.push_back(0);
        }
    file.close();
}
fstream sorting(vector<float> &untidygpa, vector<string> untidycode, fstream &data){
    fstream sorted;
    float max=0;
    int index=0;
    sorted.open("sorted.txt", ios::out);
    data.open("data.txt", ios::in);
    while(!untidygpa.empty()){
        max=0;
        int i;
        data.clear();
        data.seekg(0);
        for(i=0; i<untidygpa.size(); i++){
            if(untidygpa[i]>=max){
                max=untidygpa[i];
                index=i;
            }
        }
        string line;
        while(getline(data, line)){
            if(line.find(untidycode[index])==0){
                sorted<<line<<' '<<max<<'\n';
            }
        }
        untidycode.erase(untidycode.begin()+index);
        untidygpa.erase(untidygpa.begin()+index);
    }
    sorted.close();
    data.close();
    return sorted;
}

int main(){
    fstream data, scores, sorted;
    string guide="enter the command number:\n1.add student\n2.add lesson\n3.listing students\n4.droping a lesson\n5.student report\n6.guide\n7.close\n";
    cout<<"hello\n"<<guide;
    while(true){
        int order;
        string name, code, field, lesson;
        vector<string> codes;
        vector<float> gpas;
        cin >> order;
        cin.ignore(); 
        switch(order){
        case 7 : {
            return 0;
        } break;
        case 1 : {
            data.open("data.txt", ios::app);
            cout<<"full name: ";
            getline(cin, name);
            cout<<"student code: ";
            getline(cin, code);
            cout<<"field: ";
            getline(cin, field);
            data<< code<< ' '<< name<< '$'<< field<< '\n';
            cout<<"name added\n";
            data.close();
        } break;
        case 2 : {
            scores.open("scores.txt", ios::app);
            int vahed;
            float score;
            cout<<"enter student code: ";
            getline(cin, code);
            cout<<"lesson name: "; getline(cin, lesson);
            cout<<"vahed: "; cin>>vahed ;
            cout<<"score:"; cin>>score;
            scores<< code<< ' '<< lesson<< ' '<< vahed<< ' '<< score<< '\n';
            scores.close();

        } break;
        case 3 : {
            data.open("data.txt", ios::in);
            listingCodes(data, codes);
            // for(string code: codes)
            //     cout<<code<<"    ";
            data.close();
            listingScores(scores, gpas, codes);
            // for(float gpa: gpas)
            //     cout<<gpa<<'\n';
            fstream sorted;
            sorted=sorting(gpas, codes, data);
            cout<<"enter the field(if you want to see all the students enter all):";
            string field; getline(cin, field);
            sorted.open("sorted.txt", ios::in);
            if(field=="all"){
                string line;
                while (getline(sorted, line))
                {
                    cout<<line<<'\n';
                }
            }
            else{
                string line;
                while(getline(sorted, line)){
                    if(line.find(field)!=-1)
                        cout<<line<<'\n';
                }
            }
            sorted.close();
            
        }
        case 4 : {
            cout << "enter the code: ";
            getline(cin, code);
            drop(code);
        }
        case 5 : {
            cout << "enter the code: ";
            getline(cin, code);
            data.open("data.txt", ios::in);
            listingCodes(data, codes);
            // for(string code: codes)
            //     cout<<code<<"    ";
            data.close();
            listingScores(scores, gpas, codes);
            // for(float gpa: gpas)
            //     cout<<gpa<<'\n';
            fstream sorted;
            sorted=sorting(gpas, codes, data);
            report(code);
        } break;
        case 6 :
            cout<<guide;
            break;
        default :
            cout<<"undefined order!!\n";
            return 0;
    }}
    
}
void drop(string code) {
    fstream scores("scores.txt", ios::in);
    if (!scores) {
        cout << "Error opening file!\n";
        return;
    }

    string title;
    cout << "Enter course title: ";
    getline(cin, title);

    vector<string> lines;
    string line;
    bool found = false;

    while (getline(scores, line)) {
        if (line.find(code) != string::npos && line.find(title) != string::npos) {
            found = true;
            continue;
        }
        lines.push_back(line);
    }
    scores.close();

    if (!found) {
        cout << "Student or course not found!\n";
        return;
    }

    scores.open("scores.txt", ios::out | ios::trunc);
    for (const string &l : lines) {
        scores << l << "\n";
    }
    scores.close();

    cout << "Course dropped successfully!\n";
}
void report(string code){
   fstream scores("scores.txt", ios::in);
   fstream sorted("sorted.txt", ios::in);
   string word, word1;
   while(sorted>>word){
    if(word == code){
        string name, field;
        float gpa;
        sorted >> name >> field >> gpa;
        cout << left << setw(10) << "Name:" << setw(20) << name 
                 << setw(10) << "Field:" << setw(15) << field 
                 << setw(5) << "Gpa:" << setw(5) << gpa << "\n\n";
        break;
    }
    

   }
   cout << left << setw(25) << "Course" 
         << setw(10) << "Unit" 
         << setw(10) << "Grade" << endl;
    
    cout << string(45, '-') << endl;

   while(scores >> word1){
    if(word1 == code){
        string course;
        float unit, grade;
        scores >> course >> unit >> grade;
       cout << left << setw(25) << course 
                 << setw(10) << unit 
                 << setw(10) << grade << endl;
    }
   }
   
}